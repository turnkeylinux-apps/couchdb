.. include:: global.rst.inc

.. api_reference:

=============
API Reference
=============

`watchdog.events`
=================

.. automodule:: watchdog.events


`watchdog.observers.api`
========================

.. automodule:: watchdog.observers.api


`watchdog.observers`
====================

.. automodule:: watchdog.observers


`watchdog.utils`
================

.. automodule:: watchdog.utils


`watchdog.utils.dirsnapshot`
============================

.. automodule:: watchdog.utils.dirsnapshot


.. toctree::
   :maxdepth: 2
